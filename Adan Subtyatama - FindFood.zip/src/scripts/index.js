import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import './component/AppBar';
import './component/AppFooter';
import './component/AppListCard';
import data from '../DATA.json';

const menu = document.querySelector('#menu');
const drawer = document.querySelector('#drawer');
const linkmenu = document.getElementsByClassName('linkmenus');
const cardList = document.querySelector('app-listcard');   
const searchField = document.querySelector('#search');
const searchButton = document.querySelector('#buttonSearch');
document.addEventListener('DOMContentLoaded', function(){
    
    const fallbackResults = (message) => {
        cardList.renderError(message);
    }

    const renderItemAll = (data) => {
        try {
            cardList.items = data;            
        }catch{
            fallbackResults("Error");
        }
       
     };
     
     searchButton.addEventListener('click', function(event) {
        let restaurantTemp = [];
        let searchRestaurant = "[^,]*" + searchField.value + "[,$]*";
        data.restaurants.map(restaurant => {
            if(restaurant.city.match(searchRestaurant) || restaurant.name.match(searchRestaurant) || restaurant.city.match(searchRestaurant)){
                restaurantTemp.push(restaurant);
            }
        })
        renderItemAll(restaurantTemp);
     });
     
    menu.addEventListener('click', function (event) {
        showMenu();
    });

    const showMenu = () =>{
        drawer.classList.toggle('open');
        event.stopPropagation();
        for(var i = 0, length = linkmenu.length; i < length; i++) {
            if(linkmenu[i].hasAttribute('tabindex')){
                linkmenu[i].removeAttribute('tabindex')
            }else{
                linkmenu[i].setAttribute('tabindex', -1);
            }
    
        };
       
    }
    renderItemAll(data.restaurants);
})

