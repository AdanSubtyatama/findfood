import './AppCard';
 
class AppListCard extends HTMLElement {
  
    set items(items){
        this._items = items;
        this.render()
      }
     
 
   renderError(message) {
    this.innerHTML = `
    <h2 class="text-danger text-center">${message}</h2>`;
  }
 
  render() {
    this.innerHTML = `
    `;
    this._items.forEach(restaurant => {
        const cardItemElement = document.createElement("app-card");
        cardItemElement.restaurants = restaurant;
           this.appendChild(cardItemElement);
      });
}
}

customElements.define("app-listcard", AppListCard);